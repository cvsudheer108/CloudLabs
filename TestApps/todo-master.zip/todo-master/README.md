# TodoMVC app using React.js+Swarm.js combo

[Forked from here](https://github.com/gritzko/swarm)

and used to illustrate basic Docker concepts.

